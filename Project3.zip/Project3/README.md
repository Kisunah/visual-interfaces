# Visual Interfaces Project 3

The project is hosted publicly <a href="https://homepages.uc.edu/~hanusisw/visual-interfaces-project3/">here</a>

The computing for the word cloud takes time, so if it does not load right away, give it a few seconds to finish processing to display everything. 

GitHub: <a href="https://github.com/Kisunah/visual-interfaces/tree/main/Project3">Repo</a>

## Team Seth
I worked on this project by myself, Seth Hanusik.